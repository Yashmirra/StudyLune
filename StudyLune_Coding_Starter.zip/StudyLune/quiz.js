/* Sample quiz is clearly illustrative, not official exam content. */
window.STUDYLUNE_QUIZ = {
  question: "Which habit can make a revision session more manageable?",
  answers: ["Study every subject at once", "Choose one clear, small goal", "Skip every break", "Wait until you feel perfectly ready"],
  correct: 1,
  explanation: "A specific, realistic goal helps you begin and makes progress easier to notice."
};
