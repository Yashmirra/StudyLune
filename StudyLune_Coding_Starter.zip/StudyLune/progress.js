/* Progress counters are based only on activity recorded in this browser. */
window.StudyLuneProgress = {
  taskKey: "studylune.tasks.v1",
  journalKey: "studylune.journal.v1",
  quizKey: "studylune.quizAttempts.v1"
};
