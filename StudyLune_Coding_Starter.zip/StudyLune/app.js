(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const store = {
    get(key, fallback){ try { const v=localStorage.getItem(key); return v===null?fallback:JSON.parse(v); } catch { return fallback; } },
    set(key, value){ try { localStorage.setItem(key, JSON.stringify(value)); } catch {} }
  };
  let activeForm = "Form 4", timerSeconds = 1500, timerInterval = null, quizAnswered = false;
  const toast = (message) => { const el=$("#toast"); el.textContent=message; el.classList.add("show"); clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.remove("show"),2400); };
  const pageNames = {home:"Welcome",dashboard:"Dashboard",subjects:"Study Centre",arena:"Exam Arena",planner:"Study Planner",rooms:"Study Rooms",journal:"Study Journal",progress:"Progress",settings:"Appearance & settings"};
  function navigate(name){
    if(!pageNames[name]) return;
    $$(".page").forEach(p=>p.classList.toggle("active-page",p.id===`page-${name}`));
    $$(".nav-item[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
    $("#pageLabel").textContent=pageNames[name];
    $("#sidebar").classList.remove("open");
    window.scrollTo({top:0,behavior:document.body.classList.contains("reduce-motion")?"auto":"smooth"});
    if(name==="progress") refreshProgress();
    if(name==="subjects") renderSubjects();
  }
  document.addEventListener("click",e=>{
    const target=e.target.closest("[data-page]");
    if(target){e.preventDefault();navigate(target.dataset.page);}
  });
  $("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
  $("#themeQuick").addEventListener("click",()=>setMode(document.body.dataset.mode==="dark"?"light":"dark"));
  function setMode(mode){
    document.body.dataset.mode=mode;
    $$(".mode-card").forEach(b=>b.classList.toggle("selected",b.dataset.mode===mode));
    store.set("studylune.mode",mode);
  }
  const palettes=[
    ["lavender","Lavender",["#faf7ff","#eee6f7","#c4a7ef"]],
    ["rose","Dusty rose",["#fff7f7","#f5e6eb","#e9aeca"]],
    ["sage","Sage garden",["#f5faf6","#e5f0e8","#9ccbb3"]],
    ["butter","Buttercream",["#fffbef","#f6efd7","#e7c86e"]],
    ["ocean","Soft ocean",["#f2f9fc","#dfeef4","#8fc7df"]],
    ["peach","Peach glow",["#fff7f0","#f5e7db","#eeb58e"]],
    ["berry","Berry milk",["#fff6fb","#f1e2f0","#d6a2d8"]],
    ["slate","Cloud slate",["#f5f7fb","#e5eaf4","#aab9e8"]]
  ];
  function renderPalettes(){
    $("#paletteGrid").innerHTML=palettes.map(([id,name,colors])=>`<button class="palette-btn ${document.body.dataset.palette===id?"selected":""}" data-palette="${id}"><span class="swatches">${colors.map(c=>`<i style="background:${c}"></i>`).join("")}</span><b>${name}</b></button>`).join("");
    $$(".palette-btn").forEach(b=>b.addEventListener("click",()=>setPalette(b.dataset.palette)));
  }
  function setPalette(id){document.body.dataset.palette=id;store.set("studylune.palette",id);renderPalettes();toast(`${palettes.find(p=>p[0]===id)?.[1]||"Palette"} palette selected`);}
  $$(".mode-card").forEach(b=>b.addEventListener("click",()=>setMode(b.dataset.mode)));
  renderPalettes();
  setMode(store.get("studylune.mode","dark"));
  setPalette(store.get("studylune.palette","lavender"));
  $("#motionToggle").checked=store.get("studylune.motion",true);
  $("#motionToggle").addEventListener("change",e=>{store.set("studylune.motion",e.target.checked);document.body.classList.toggle("reduce-motion",!e.target.checked||$("#reduceMotion").checked);});
  $("#reduceMotion").addEventListener("change",e=>{document.body.classList.toggle("reduce-motion",e.target.checked||!$("#motionToggle").checked);store.set("studylune.reduceMotion",e.target.checked);});
  $("#reduceMotion").checked=store.get("studylune.reduceMotion",false);
  document.body.classList.toggle("reduce-motion",$("#reduceMotion").checked||!$("#motionToggle").checked);

  function renderSubjects(query=""){
    const grid=$("#subjectGrid"); if(!grid)return;
    const list=window.STUDYLUNE_SUBJECTS||[];
    const filtered=list.filter(([name])=>name.toLowerCase().includes(query.toLowerCase()));
    grid.innerHTML=filtered.map(([name,abbr,tint])=>`<button class="subject-card" data-subject="${name}" style="--subject-tint:${tint.trim()}"><span class="subject-symbol">${abbr}</span><b>${name}</b><small>${activeForm} · Subject overview</small></button>`).join("");
    if(!filtered.length)grid.innerHTML='<p class="muted">No subjects match that search. Try another keyword.</p>';
    $$(".subject-card",grid).forEach(b=>b.addEventListener("click",()=>{toast(`${b.dataset.subject} selected — verified chapters will be added next.`);}));
  }
  $("#subjectSearch").addEventListener("input",e=>renderSubjects(e.target.value));
  $$(".form-option").forEach(b=>b.addEventListener("click",()=>{
    const group=b.closest(".form-switch"); $$(".form-option",group).forEach(x=>x.classList.toggle("selected",x===b));
    activeForm=b.dataset.form;renderSubjects($("#subjectSearch").value);
    $$(".form-option").forEach(x=>{if(x.dataset.form===activeForm)x.classList.add("selected");});
  }));
  $$(".quick-subjects button").forEach(b=>b.addEventListener("click",()=>{navigate("subjects");$("#subjectSearch").value=b.dataset.subject;renderSubjects(b.dataset.subject);}));
  renderSubjects();

  $("#globalSearch").addEventListener("keydown",e=>{if(e.key==="Enter"){const q=e.target.value.trim();if(!q)return; navigate("subjects");$("#subjectSearch").value=q;renderSubjects(q);}});
  $("#globalSearch").addEventListener("input",e=>{if(e.target.value.length===0&&$("#page-subjects").classList.contains("active-page"))renderSubjects();});

  const initialTasks=[
    {id:"welcome-1",title:"Review one topic",subject:"Choose a subject",date:"",done:false},
    {id:"welcome-2",title:"Try a quick quiz",subject:"Exam Arena",date:"",done:false},
    {id:"welcome-3",title:"Write a short reflection",subject:"Study Journal",date:"",done:false}
  ];
  function tasks(){return store.get(StudyLunePlanner.storageKey,initialTasks);}
  function saveTasks(data){store.set(StudyLunePlanner.storageKey,data);renderPlanner();refreshProgress();}
  function renderPlanner(){
    const data=tasks(), root=$("#plannerTasks"); if(!root)return;
    $("#plannerCount").textContent=`${data.length} TASK${data.length===1?"":"S"}`;
    root.innerHTML=data.length?data.map(t=>`<div class="planner-task"><input type="checkbox" data-task-check="${t.id}" ${t.done?"checked":""} aria-label="Mark ${escapeHTML(t.title)} complete"><div class="planner-task-main"><b style="${t.done?"text-decoration:line-through;opacity:.55":""}">${escapeHTML(t.title)}</b><small>${escapeHTML(t.subject)}${t.date?" · "+escapeHTML(t.date):""}</small></div><button class="delete-task" data-task-delete="${t.id}" aria-label="Delete task">×</button></div>`).join(""):'<p class="muted empty-state">No tasks yet. Add one small step above.</p>';
    $$("[data-task-check]",root).forEach(c=>c.addEventListener("change",()=>{const d=tasks().map(t=>t.id===c.dataset.taskCheck?{...t,done:c.checked}:t);saveTasks(d);}));
    $$("[data-task-delete]",root).forEach(b=>b.addEventListener("click",()=>saveTasks(tasks().filter(t=>t.id!==b.dataset.taskDelete))));
    const completed=data.filter(t=>t.done).length;
    $("#taskCount").innerHTML=`${completed} <small>/ ${data.length}</small>`;
    $("#taskProgress").style.width=data.length?`${completed/data.length*100}%`:"0%";
    $("#dashboardTasks").innerHTML=data.slice(0,3).map((t,i)=>`<label class="task-row"><input type="checkbox" class="task-check" data-dash-check="${t.id}" ${t.done?"checked":""}><span class="task-box"></span><span class="task-copy"><b>${escapeHTML(t.title)}</b><small>${escapeHTML(t.subject)}</small></span><span class="task-tag ${i===1?"rose-tag":i===2?"green-tag":""}">${i===1?"PRACTISE":i===2?"REFLECT":"FOCUS"}</span></label>`).join("")||'<p class="muted empty-state">Add a task in your planner to get started.</p>';
    $$("[data-dash-check]").forEach(c=>c.addEventListener("change",()=>saveTasks(tasks().map(t=>t.id===c.dataset.dashCheck?{...t,done:c.checked}:t))));
  }
  $("#taskForm").addEventListener("submit",e=>{
    e.preventDefault();const title=$("#taskInput").value.trim();if(!title)return;
    const data=tasks();data.push({id:`task-${Date.now()}`,title,subject:$("#taskSubject").value,date:$("#taskDate").value,done:false});
    saveTasks(data);e.target.reset();toast("Task added to your planner.");
  });
  renderPlanner();

  let journal=store.get(StudyLuneProgress.journalKey,[]);
  function renderJournal(){
    const root=$("#journalEntries");journal=store.get(StudyLuneProgress.journalKey,[]);
    root.innerHTML=journal.length?[...journal].reverse().map(e=>`<div class="journal-entry"><small>${escapeHTML(e.mood)} · ${new Date(e.created).toLocaleDateString()}</small><p>${escapeHTML(e.text)}</p><button class="entry-delete" data-entry-delete="${e.id}">Delete entry</button></div>`).join(""):'<p class="muted empty-state">Your saved reflections will appear here.</p>';
    $$("[data-entry-delete]",root).forEach(b=>b.addEventListener("click",()=>{journal=journal.filter(e=>e.id!==b.dataset.entryDelete);store.set(StudyLuneProgress.journalKey,journal);renderJournal();refreshProgress();toast("Reflection deleted.");}));
  }
  $("#journalForm").addEventListener("submit",e=>{e.preventDefault();journal=store.get(StudyLuneProgress.journalKey,[]);journal.push({id:`entry-${Date.now()}`,mood:$("#journalMood").value,text:$("#journalEntry").value.trim(),created:Date.now()});store.set(StudyLuneProgress.journalKey,journal);$("#journalEntry").value="";renderJournal();refreshProgress();toast("Reflection saved on this device.");});
  renderJournal();

  function refreshProgress(){
    const data=tasks(), entries=store.get(StudyLuneProgress.journalKey,[]), attempts=store.get(StudyLuneProgress.quizKey,0);
    $("#progressTasks").textContent=data.filter(t=>t.done).length;$("#progressJournal").textContent=entries.length;$("#progressQuiz").textContent=attempts;
  }
  function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  window.StudyLuneUtils={toast,escapeHTML,store,refreshProgress};

  $("#quickQuiz").addEventListener("click",()=>{
    quizAnswered=false;const q=window.STUDYLUNE_QUIZ,root=$("#quizArea");root.classList.remove("hidden");
    root.innerHTML=`<p class="eyebrow">ILLUSTRATIVE SAMPLE · NOT OFFICIAL EXAM CONTENT</p><h3>Quick practice</h3><p class="quiz-question">${escapeHTML(q.question)}</p><div>${q.answers.map((a,i)=>`<button class="quiz-answer" data-answer="${i}">${escapeHTML(a)}</button>`).join("")}</div><div id="quizFeedback"></div>`;
    $$("[data-answer]",root).forEach(b=>b.addEventListener("click",()=>{if(quizAnswered)return;quizAnswered=true;const correct=Number(b.dataset.answer)===q.correct;root.querySelectorAll("[data-answer]").forEach(x=>x.disabled=true);$("#quizFeedback").innerHTML=`<div class="quiz-feedback">${correct?"Correct — well done.":"Not quite — that’s okay."} ${escapeHTML(q.explanation)}</div><button class="primary-btn" id="quizDone">Finish practice ↗</button>`;let count=store.get(StudyLuneProgress.quizKey,0)+1;store.set(StudyLuneProgress.quizKey,count);$("#quizDone").addEventListener("click",()=>{root.classList.add("hidden");refreshProgress();toast("Practice attempt recorded.");});}));
    root.scrollIntoView({behavior:document.body.classList.contains("reduce-motion")?"auto":"smooth",block:"nearest"});
  });
  $("#createRoom").addEventListener("click",()=>{const n=$("#roomNotice");n.classList.remove("hidden");n.innerHTML='<p class="eyebrow">ROOM SETUP PREVIEW</p><h3>A focused session starts with a shared goal.</h3><p class="muted">Choose one subject, agree on a session length and set a kind, clear goal. Live room creation and invitations are not connected in this local prototype.</p><button class="secondary-btn" id="roomGotIt">Got it</button>';$("#roomGotIt").addEventListener("click",()=>n.classList.add("hidden"));});
  $("#resetData").addEventListener("click",()=>{if(confirm("Clear all StudyLune tasks, reflections and saved appearance preferences from this browser?")){Object.keys(localStorage).filter(k=>k.startsWith("studylune.")).forEach(k=>localStorage.removeItem(k));location.reload();}});
  $("#timerStart").addEventListener("click",()=>{
    if(timerInterval){clearInterval(timerInterval);timerInterval=null;$("#timerStart").textContent="Resume focus";return;}
    $("#timerStart").textContent="Pause";
    timerInterval=setInterval(()=>{timerSeconds--;if(timerSeconds<=0){clearInterval(timerInterval);timerInterval=null;timerSeconds=0;$("#timerStart").textContent="Start again";toast("Focus session complete. Take a short break if you need one.");}updateTimer();},1000);
  });
  $("#timerReset").addEventListener("click",()=>{clearInterval(timerInterval);timerInterval=null;timerSeconds=1500;$("#timerStart").textContent="Start focus";updateTimer();});
  function updateTimer(){$("#timerDisplay").textContent=`${String(Math.floor(timerSeconds/60)).padStart(2,"0")}:${String(timerSeconds%60).padStart(2,"0")}`;}
  refreshProgress();
})();