/* Subject catalogue only. Add chapter content after checking current KSSM sources. */
window.STUDYLUNE_SUBJECTS = [
  ["Bahasa Melayu","BM","#e8b5d0"],["English","EN","#b9c6f0"],["Sejarah","SE"," #f2d99a"],
  ["Mathematics","∑","#c9b6ee"],["Sains / Science","Sc","#a9d5c0"],["Matematik Tambahan","∫","#d8c1f0"],
  ["Fizik / Physics","Ph","#a8d7e6"],["Kimia / Chemistry","Ch","#edc0a5"],["Biologi / Biology","Bi","#acd9c1"],
  ["Sains Komputer","</>","#b6c6ed"],["Sains Pertanian","Ag","#c4dca4"],["Sains Sukan","Sp","#e8b4c7"],
  ["Sains Rumah Tangga","⌂","#f0dba0"],["Prinsip Perakaunan","₊","#c8b5e8"],["Ekonomi","↗","#a8d9d0"],
  ["Perniagaan","▣","#edc2a4"],["Pendidikan Seni Visual","✿","#e9b3d0"],["Pendidikan Muzik","♫","#b9c6f0"]
];
window.STUDYLUNE_SUBJECT_ICONS = {};
