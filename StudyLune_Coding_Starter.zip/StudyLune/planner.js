/* Planner behaviours are wired in app.js; kept separate for future expansion. */
window.StudyLunePlanner = { storageKey: "studylune.tasks.v1" };
